<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial- scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Halaman <?= $data['judul']; ?></title>
    </head>
    <body>
        <div class="col-sm-15">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title"><strong>KOMPETENSI KEAHLIAN SMK NEGERI 2 TRENGGALEK</strong></h5> <br/> 
                <div class="row">
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/7.png" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>AKL</strong></h5>
                                <p class="card-text">Akuntansi adalah sebuah Kompetensi Keahlian (Jurusan) yang sangat berhubungan dengan angka dan hitung menghitung.
                                    Hampir setiap hari kalian akan dihadapkan dengan pelajaran hitung menghitung.</p> </br>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/11.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>TB</strong></h5>
                                <p class="card-text">Tata Boga adalah ilmu tentang bagaimana teknik untuk menyajikan makanan dengan memperhatikan beberapa faktor yaitu estetika atau keindahan, kualitas rasa masakan, serta nilai kebutuhan gizinya.</p> </br>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/8.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>DPIB</strong></h5>
                                <p class="card-text">Desain Pemodelan dan Informasi Bangunan adalah jurusan yang mempelajari tentang perencanaan bangunan, pelaksanaan pembuatan gedung dan perbaikan gedung.
                                    Kegiatannya adalah belajar menggambar rumah, gedung dan apartemen, menghitung biaya bangunan, melaksankan pembangunan dan memelihara kontruksi bangunan.</p> </br>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/9.png" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>KGSP</strong></h5>
                                <p class="card-text">Kontruksi Gedung Sanitasi dan Perawatan (KGSP) adalah sebuah Paket Keahlian baru, para peserta didik akan belajar tentang membangun sebuah bangunan, sanitasi dan kegiatan untuk merawatnya.
                                    Program belajar KGSP ini, diikuti oleh peserta didik selama 4 tahun.</p> </br>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/6.png" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>RPL</strong></h5>
                                <p class="card-text">RPL adalah sebuah jurusan yang mempelajari dan mendalami semua cara-cara pengembangan perangkat lunak termasuk pembuatan, pemeliharaan, manajemen organisasi pengembangan perangkat lunak dan manajemen kualitas.</p> </br>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-15">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/10.png" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title"><strong>TPTU</strong></h5>
                                <p class="card-text">Teknik Pendinginan dan Tata Udara (TPTU) merupakan salah satu Kompetensi Keahlian dari Program Keahlian: Teknik Ketenagalistrikan dan Bidang Keahlian: Teknologi dan Rekayasa.</p> </br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>