<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
</head>

<body>
    <div class="container mt-5">
        <div class="card" style="max-width: 540px;">
            <div class="row no-gutters">
                <div class="col-md-4">
                    <img src="img/gambar5.jpeg" class="card-img" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">PREMITA ALIFYA KASISNA</h5>
                        <p class="card-text">Nama          : Premita Alifya Kasisna</p>
                        <p class="card-text">Absen         : 11</p>
                        <p class="card-text">Kelas         : XII RPL C</p>
                        <p class="card-text">Tanggal lahir : Trenggalek,20 - 09 - 2004</p>
                        <p class="card-text">Sekolah       : SMKn 2 Trenggalek</p>
                        <p class="card-text">Instagram     : @prmtalfy</p>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>